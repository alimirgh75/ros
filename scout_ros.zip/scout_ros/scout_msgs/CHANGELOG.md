# Changelog for package scout_msgs

## 0.0.1 (2019-06-14)
------------------
* Initial development of scout_msgs for Scout
* Contributors: Ruixiang Du
